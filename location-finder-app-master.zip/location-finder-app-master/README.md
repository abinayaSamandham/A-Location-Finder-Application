App name: location-finder-react-app.
Description: React App to help students to find the locations in their city