import axios from 'axios';

export default axios.create({
  baseURL: `https://skatkar225-eval-test.apigee.net`
  //baseURL: `http://35.224.174.185`
});